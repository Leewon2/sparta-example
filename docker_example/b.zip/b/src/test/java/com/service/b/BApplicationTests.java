package com.service.b;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BApplicationTests {

	@Test
	void contextLoads() {
	}

}
